package com.example.gshare.Notice;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gshare.R;

public class ActivityContqactTry extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedBundleInstance){
        super.onCreate(savedBundleInstance);
        setContentView(R.layout.fragment_noticecontactyellow);
    }

}
